package april16SpaceHotel;
import java.util.*;

public class TravellerMain {
//change to SYSTEM SHOCK 2 universe
	
	public static void main(String[] args) {
		String shipArea;
		String monsterType;
		int scareLvl;
		
Scanner input = new Scanner(System.in);

//prompts for the user inputs
System.out.println("where are you in the Von Braun? ");
shipArea= input.nextLine();

System.out.println("what are you fighting? ");
monsterType=input.nextLine();

System.out.println("how do you feel? 1-5");
scareLvl=input.nextInt();

//attaching the two files
Planetvibe call1 = new Planetvibe(shipArea, monsterType, scareLvl);

//where the magic works
call1.TestGreet();
call1.SpeciesType();
call1.Power();

	}

}
