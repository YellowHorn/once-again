package april16SpaceHotel;
import java.util.*;
//instance variables
public class Planetvibe {
String shipArea;
String monsterType;
int scareLvl;
//constructor parameterized
public Planetvibe(String shipArea, String monsterType, int scareLvl) {
	this.shipArea = shipArea;
	this.monsterType = monsterType;
	this.scareLvl = scareLvl;
}

// all the possible inputs for the scanner
void TestGreet() {
	if(shipArea.equals("Engineering Deck") || shipArea.equals("MedSci Deck") || shipArea.equals("Hydroponics Deck") || shipArea.equals("Operations Deck") || shipArea.equals("Recreaction Deck") 
			|| shipArea.equals("Command Deck")){
		System.out.println("Welcome to " + this.shipArea);
	}
	else {
		System.out.println("uh oh, looks like you fell into outer space!");
	}
}

//this willl generate statement regarding species
void SpeciesType(){
System.out.println("these  "+ this.monsterType + " are pretty spooky ");
}


//different status'
void Power() {
	switch (scareLvl) {
	case 1: 
		System.out.println("this isnt good your low on health!");
	for(int i=0; i<2; i++) {
		System.out.println("WARNING");
	}
	break;
	case 2:
		System.out.println("you need a Medical Hypo to survive");
		for(int i=0; i<3; i++) {
			System.out.println(" *Injecting Hypo* ");
	}
	break;
	case 3:
		System.out.println("your doing well");
	for(int i=0; i<4; i++) {
		System.out.println("Keep fighting!");
}
	break;
	case 4: 
		System.out.println("barely a scratch on you");
	for(int i=0; i<5; i++) {
		System.out.println("flex The Many to death");
	}
	break;
	case 5: System.out.println("Perfect Health");
	for(int i=0; i<6; i++) {
		System.out.println("not for long");
	}
	break;
	default: {
		System.out.println(" you have been turned into SHODAN's creature ");
		}	
	}
}
}
